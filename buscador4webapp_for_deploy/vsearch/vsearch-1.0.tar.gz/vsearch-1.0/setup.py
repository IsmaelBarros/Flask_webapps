from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='Ferramenta para busca no webapp',
    author='Ismael',
    author_email='ismasbarros2@gmail.com',
    url='https://github.com/ismaemahh',
    py_modules=['vsearch'],

)