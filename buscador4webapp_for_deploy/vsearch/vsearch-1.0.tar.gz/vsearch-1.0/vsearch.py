def search4vowel(word: str) -> set:
    """Display any vowel found in an asked-for word"""
    vowels = set('aeiou')
    return set(vowels).intersection(set(word))


def search4letters(phrase: str, letters: str='aeiou') -> set:
    """Display any letter found in an asked-for phrase."""
    return set(letters).intersection(set(phrase))